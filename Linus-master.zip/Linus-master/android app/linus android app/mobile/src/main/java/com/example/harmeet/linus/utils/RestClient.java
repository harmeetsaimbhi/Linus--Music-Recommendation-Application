package com.example.harmeet.linus.utils;

/**
 * Created by Ishmeet on 11/04/16.
 */
public class RestClient {
}
